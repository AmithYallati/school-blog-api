from fastapi import FastAPI, HTTPException
from motor.motor_asyncio import AsyncIOMotorClient
from bson import ObjectId
from models import BlogPost, BlogPostInDB
from database import blog_collection

app = FastAPI()

@app.post("/posts/", response_model=BlogPost)
async def create_blog_post(post: BlogPostInDB):
    post_dict = post.dict()
    result = await blog_collection.insert_one(post_dict)
    post_dict["id"] = str(result.inserted_id)
    return post_dict

@app.get("/posts/{post_id}", response_model=BlogPost)
async def get_blog_post(post_id: str):
    post = await blog_collection.find_one({"_id": ObjectId(post_id)})
    if post is None:
        raise HTTPException(status_code=404, detail="Post not found")
    post["id"] = str(post["_id"])
    return post

@app.put("/posts/{post_id}", response_model=BlogPost)
async def update_blog_post(post_id: str, post: BlogPostInDB):
    result = await blog_collection.replace_one({"_id": ObjectId(post_id)}, post.dict())
    if result.modified_count == 0:
        raise HTTPException(status_code=404, detail="Post not found")
    return {**post.dict(), "id": post_id}

@app.delete("/posts/{post_id}")
async def delete_blog_post(post_id: str):
    result = await blog_collection.delete_one({"_id": ObjectId(post_id)})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Post not found")
    return {"detail": "Post deleted"}
