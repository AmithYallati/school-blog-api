from pydantic import BaseModel
from typing import Optional

class BlogPost(BaseModel):
    id: Optional[str] = None
    title: str
    content: str

class BlogPostInDB(BaseModel):
    title: str
    content: str
