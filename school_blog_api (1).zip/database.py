import motor.motor_asyncio
from bson import ObjectId

client = motor.motor_asyncio.AsyncIOMotorClient("mongodb://localhost:27017")
database = client.school_blog
blog_collection = database.blog_posts

class BlogPostInDB:
    def __init__(self, title: str, content: str):
        self.title = title
        self.content = content

    def to_dict(self):
        return {"title": self.title, "content": self.content}
