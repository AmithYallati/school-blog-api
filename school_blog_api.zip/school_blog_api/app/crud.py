
from bson import ObjectId
from app.config import blog_collection
from app.schemas import BlogSchema

async def add_blog(blog_data: BlogSchema) -> dict:
    blog = await blog_collection.insert_one(blog_data.dict())
    return await get_blog(str(blog.inserted_id))

async def get_blog(blog_id: str) -> dict:
    blog = await blog_collection.find_one({"_id": ObjectId(blog_id)})
    if blog:
        return blog_helper(blog)

async def get_blogs():
    blogs = []
    async for blog in blog_collection.find():
        blogs.append(blog_helper(blog))
    return blogs

async def update_blog(blog_id: str, data: dict):
    if len(data) < 1:
        return False
    blog = await blog_collection.find_one({"_id": ObjectId(blog_id)})
    if blog:
        updated_blog = await blog_collection.update_one(
            {"_id": ObjectId(blog_id)}, {"$set": data}
        )
        return updated_blog

async def delete_blog(blog_id: str):
    blog = await blog_collection.find_one({"_id": ObjectId(blog_id)})
    if blog:
        await blog_collection.delete_one({"_id": ObjectId(blog_id)})
        return True
    return False

def blog_helper(blog) -> dict:
    return {
        "id": str(blog["_id"]),
        "title": blog["title"],
        "content": blog["content"],
        "author": blog["author"],
        "tags": blog.get("tags", []),
    }
