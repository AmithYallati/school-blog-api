# app/schemas.py
from pydantic import BaseModel, Field
from typing import Optional

class BlogSchema(BaseModel):
    title: str = Field(...)
    content: str = Field(...)
    author: str = Field(...)
    tags: Optional[list] = []

    class Config:
        json_schema_extra = {  # Changed from schema_extra
            "example": {
                "title": "My First Blog",
                "content": "This is the content of the blog.",
                "author": "Jane Doe",
                "tags": ["education", "school", "blog"]
            }
        }

class UpdateBlogSchema(BaseModel):
    title: Optional[str]
    content: Optional[str]
    author: Optional[str]
    tags: Optional[list]
