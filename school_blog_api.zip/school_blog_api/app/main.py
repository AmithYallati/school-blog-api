from fastapi import FastAPI, HTTPException
from app.schemas import BlogSchema, UpdateBlogSchema
from app.crud import add_blog, get_blog, get_blogs, update_blog, delete_blog

app = FastAPI()

# Root route to confirm API is running
@app.get("/")
async def read_root():
    return {"message": "Welcome to the School Blog API!"}

# Create a new blog post
@app.post("/blogs", response_description="Add a new blog")
async def create_blog(blog: BlogSchema):
    new_blog = await add_blog(blog)
    return new_blog

# Get a single blog post by ID
@app.get("/blogs/{id}", response_description="Get a single blog")
async def read_blog(id: str):
    blog = await get_blog(id)
    if blog:
        return blog
    raise HTTPException(status_code=404, detail="Blog not found")

# Get all blog posts
@app.get("/blogs", response_description="Get all blogs")
async def read_blogs():
    blogs = await get_blogs()
    return blogs

# Update a blog post by ID
@app.put("/blogs/{id}", response_description="Update a blog")
async def update_blog_data(id: str, blog: UpdateBlogSchema):
    updated_blog = await update_blog(id, blog.dict(exclude_unset=True))
    if updated_blog:
        return {"message": "Blog updated successfully"}
    raise HTTPException(status_code=404, detail="Blog not found")

# Delete a blog post by ID
@app.delete("/blogs/{id}", response_description="Delete a blog")
async def delete_blog_data(id: str):
    deleted = await delete_blog(id)
    if deleted:
        return {"message": "Blog deleted successfully"}
    raise HTTPException(status_code=404, detail="Blog not found")
